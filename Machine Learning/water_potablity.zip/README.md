# water-potablity-using-svm-and-random-forest
please ensure that the machine used has python installed and ready to run
download the files and ensure that they are in the same folder, once that's done run the file
